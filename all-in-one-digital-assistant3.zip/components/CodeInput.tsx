import React from 'react';
import Editor from '@monaco-editor/react';

interface CodeInputProps {
  language: string;
  value: string;
  onChange: (value: string | undefined) => void;
}

const CodeInput: React.FC<CodeInputProps> = ({ language, value, onChange }) => {
  return (
    <div className="h-full w-full">
      <Editor
        height="100%"
        language={language}
        value={value}
        onChange={onChange}
        theme="vs-dark"
        options={{
          minimap: { enabled: false },
          fontSize: 14,
          wordWrap: 'on',
          scrollBeyondLastLine: false,
          automaticLayout: true,
        }}
      />
    </div>
  );
};

export default CodeInput;