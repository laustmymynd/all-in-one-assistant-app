import React, { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { CopyIcon } from './icons/CopyIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { InfoIcon } from './icons/InfoIcon';
import { LANGUAGE_DETAILS } from '../constants';

interface ComparisonPanelProps {
  modelName: string;
  content: string;
  isLoading: boolean;
  error: string | null;
  language: string;
}

const extractCode = (markdown: string) => {
    const codeBlockRegex = /```(?:\w*\n)?([\s\S]*?)```/;
    const match = markdown.match(codeBlockRegex);
    return match ? match[1].trim() : markdown;
};

export const ComparisonPanel: React.FC<ComparisonPanelProps> = ({ modelName, content, isLoading, error, language }) => {
    const [copied, setCopied] = useState(false);
    
    useEffect(() => {
        if (copied) {
          const timer = setTimeout(() => setCopied(false), 2000);
          return () => clearTimeout(timer);
        }
    }, [copied]);

    const handleCopy = () => {
        if (!content) return;
        navigator.clipboard.writeText(extractCode(content));
        setCopied(true);
    };
    
    const handleDownload = () => {
        const languageDetails = LANGUAGE_DETAILS[language];
        let filename = `generated_code_${modelName}.txt`;
        let mimeType = 'text/plain';

        if (languageDetails) {
            filename = `generated_code_${modelName}.${languageDetails.extension}`;
            mimeType = languageDetails.mime;
        }
        
        const blob = new Blob([extractCode(content)], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="flex flex-col items-center justify-center h-full text-zinc-500">
                    <SpinnerIcon className="w-8 h-8 animate-spin text-red-500" />
                    <p className="mt-2 text-sm">Waiting for {modelName}...</p>
                </div>
            )
        }
        if (error) {
            return (
                <div className="flex items-center justify-center h-full p-2">
                    <div className="bg-red-900/30 border border-red-800 text-red-300 px-3 py-2 rounded-lg text-center text-sm">
                        <strong className="font-bold block mb-1">Error</strong>
                        <span>{error}</span>
                    </div>
                </div>
            )
        }
        if (!content) {
            return (
                <div className="flex flex-col items-center justify-center h-full text-zinc-600 text-center p-2">
                    <InfoIcon className="w-10 h-10 mb-2" />
                    <p className="text-sm font-medium text-zinc-400">No Output</p>
                </div>
            )
        }
        return (
           <Editor
                height="100%"
                language={language.toLowerCase()}
                value={extractCode(content)}
                theme="vs-dark"
                options={{
                    readOnly: true,
                    minimap: { enabled: false },
                    fontSize: 14,
                    wordWrap: 'on',
                    scrollBeyondLastLine: false,
                    automaticLayout: true,
                }}
            />
        )
    }

    return (
        <div className="border border-zinc-800 rounded-lg flex flex-col h-full min-h-[300px]">
            <div className="p-2 border-b border-zinc-800 flex items-center justify-between bg-zinc-800/50 rounded-t-lg">
                <h3 className="text-sm font-bold text-zinc-200 capitalize">{modelName.replace(/gemini-2.5-|gemma-2-|-it/g, '')}</h3>
                {!isLoading && content && !error && (
                    <div className="flex items-center gap-1">
                        <button onClick={handleDownload} title="Download" className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-700 rounded-md transition-colors"><DownloadIcon className="w-4 h-4" /></button>
                        <button onClick={handleCopy} title="Copy" className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-700 rounded-md transition-colors"><CopyIcon className="w-4 h-4" /></button>
                    </div>
                )}
            </div>
            <div className="p-2 flex-grow">
                {renderContent()}
            </div>
        </div>
    )
}