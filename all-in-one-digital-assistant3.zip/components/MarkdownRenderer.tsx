import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const renderMarkdown = () => {
    const elements: React.ReactNode[] = [];
    // Split by code blocks, keeping the delimiter
    const blocks = content.split(/(```[\s\S]*?```)/g);

    blocks.forEach((block, index) => {
      if (block.startsWith('```')) {
        const language = block.match(/^```(\w*)\n/)?.[1] || '';
        const code = block.replace(/^```\w*\n/, '').replace(/```$/, '');
        elements.push(
          <pre key={`code-${index}`} className="bg-zinc-950/70 rounded-md p-4 my-4 overflow-x-auto border border-zinc-800">
            <code className={`language-${language} text-sm text-zinc-300`}>{code.trim()}</code>
          </pre>
        );
      } else {
        const lines = block.trim().split('\n');
        let listItems: React.ReactNode[] = [];

        const getListItem = (liLine: string, liKey: string) => {
            const itemContent = liLine.substring(2);
            const parts = itemContent.split(/(\*\*.*?\*\*|`.*?`)/g).map((part, partIndex) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                    return <strong key={partIndex} className="font-semibold text-zinc-100">{part.slice(2, -2)}</strong>;
                }
                if (part.startsWith('`') && part.endsWith('`')) {
                    return <code key={partIndex} className="bg-zinc-700 text-orange-300 rounded-sm px-1.5 py-0.5 text-xs font-mono">{part.slice(1, -1)}</code>;
                }
                return part;
            });
            return <li key={liKey} className="text-zinc-300">{parts}</li>;
        };

        const flushList = () => {
          if (listItems.length > 0) {
            elements.push(
              <ul key={`ul-${index}-${elements.length}`} className="list-disc list-outside pl-5 mb-4 space-y-2">
                {listItems}
              </ul>
            );
            listItems = [];
          }
        };

        lines.forEach((line, lineIndex) => {
          const key = `${index}-${lineIndex}`;
          
          if (line.startsWith('### ')) {
            flushList();
            elements.push(<h3 key={key} className="text-lg font-semibold mt-6 mb-2 text-orange-400">{line.substring(4)}</h3>);
          } else if (line.startsWith('## ')) {
            flushList();
            elements.push(<h2 key={key} className="text-xl font-bold mt-8 mb-3 border-b border-zinc-700 pb-2 text-zinc-100">{line.substring(3)}</h2>);
          } else if (line.startsWith('# ')) {
            flushList();
            elements.push(<h1 key={key} className="text-2xl font-bold mt-4 mb-4 border-b-2 border-zinc-600 pb-3 text-white">{line.substring(2)}</h1>);
          } else if (line.startsWith('* ') || line.startsWith('- ')) {
            listItems.push(getListItem(line, key));
          } else if (line.trim()) {
            flushList();
            const parts = line.split(/(\*\*.*?\*\*|`.*?`)/g).map((part, partIndex) => {
                if(part.startsWith('**') && part.endsWith('**')) {
                    return <strong key={partIndex} className="font-semibold text-zinc-100">{part.slice(2, -2)}</strong>;
                }
                if (part.startsWith('`') && part.endsWith('`')) {
                    return <code key={partIndex} className="bg-zinc-700 text-orange-300 rounded-sm px-1.5 py-0.5 text-xs font-mono">{part.slice(1, -1)}</code>;
                }
                return part;
            });
            elements.push(<p key={key} className="my-3 text-zinc-300 leading-relaxed">{parts}</p>);
          }
        });

        flushList();
      }
    });

    return elements;
  };

  return <div className="prose prose-invert max-w-none">{renderMarkdown()}</div>;
};

export default MarkdownRenderer;