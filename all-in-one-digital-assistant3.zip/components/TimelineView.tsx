import React from 'react';
import { Interaction } from '../types';
import { CodeIcon } from './icons/CodeIcon';
import { PencilSwooshIcon } from './icons/PencilSwooshIcon';
import { WandIcon } from './icons/WandIcon';
import { SearchIcon } from './icons/SearchIcon';
import { SparklesIcon } from './icons/SparklesIcon';

const ActionIcon: React.FC<{ action: string }> = ({ action }) => {
    switch (action) {
        case 'explain': return <PencilSwooshIcon className="w-5 h-5" />;
        case 'find-bugs': return <SearchIcon className="w-5 h-5" />;
        case 'refactor': return <CodeIcon className="w-5 h-5" />;
        case 'generate-docs': return <WandIcon className="w-5 h-5" />;
        case 'optimize': return <SparklesIcon className="w-5 h-5" />;
        default: return <CodeIcon className="w-5 h-5" />;
    }
};

const TimelineView: React.FC<{
  history: Interaction[];
  onRestore: (item: Interaction) => void;
}> = ({ history, onRestore }) => {
  if (history.length === 0) {
    return (
      <div className="p-4 text-center text-zinc-500 h-full flex items-center justify-center">
        <p>Your session history will appear here in chronological order.</p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      {history.slice().reverse().map((item, index) => (
        <div key={item.id} className="relative pl-8">
          <div className="absolute left-0 top-1.5 w-4 h-4 bg-zinc-700 rounded-full border-4 border-zinc-900"></div>
          {index < history.length - 1 && <div className="absolute left-[7px] top-5 h-full w-0.5 bg-zinc-800"></div>}
          <button
            className="w-full text-left p-3 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700 rounded-lg cursor-pointer transition-colors"
            onClick={() => onRestore(item)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="text-orange-500"><ActionIcon action={item.action} /></div>
                <div>
                  <h4 className="font-semibold text-zinc-100 capitalize">{item.mode.replace('-', ' ')}: {item.action.replace('-', ' ')}</h4>
                  <p className="text-xs text-zinc-400">{item.language}</p>
                </div>
              </div>
              <p className="text-xs text-zinc-500">{new Date(item.timestamp).toLocaleString()}</p>
            </div>
          </button>
        </div>
      ))}
    </div>
  );
};

export default TimelineView;
