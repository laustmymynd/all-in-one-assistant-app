import React from 'react';
import MarkdownRenderer from './MarkdownRenderer';
import { DebateTurn } from '../types';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { InfoIcon } from './icons/InfoIcon';

interface DebateDisplayProps {
    debateResult: { turns: DebateTurn[], synthesis: string } | null;
    isLoading: boolean;
}

const DebateDisplay: React.FC<DebateDisplayProps> = ({ debateResult, isLoading }) => {
    if (isLoading && !debateResult) {
        return null; // The parent handles the main loading spinner
    }

    if (!debateResult || debateResult.turns.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-zinc-600 text-center p-4">
                <InfoIcon className="w-12 h-12 mb-4" />
                <p className="text-lg font-medium text-zinc-400">Debate Results</p>
                <p className="text-sm max-w-sm">The debate will be shown here.</p>
            </div>
        );
    }
    
    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {debateResult.turns.map((turn, index) => (
                    <div key={index} className="border border-zinc-800 rounded-lg bg-zinc-900/50 flex flex-col">
                        <h3 className="text-md font-bold text-zinc-200 capitalize p-3 bg-zinc-800/50 rounded-t-lg border-b border-zinc-800">
                           {turn.model.replace(/gemini-2.5-|gemma-2-|-it/g, '')}'s Argument
                        </h3>
                        <div className="p-4 space-y-4 flex-grow">
                            <div>
                                <h4 className="font-semibold text-orange-400 text-sm mb-2">Opening Statement</h4>
                                <MarkdownRenderer content={turn.initialResponse} />
                            </div>
                             <div className="border-t border-zinc-700 pt-4">
                                <h4 className="font-semibold text-blue-400 text-sm mb-2">Rebuttal</h4>
                                <MarkdownRenderer content={turn.rebuttal} />
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            
            <div className="border border-zinc-800 rounded-lg bg-zinc-900/50">
                <h3 className="text-md font-bold text-zinc-200 p-3 bg-zinc-800/50 rounded-t-lg border-b border-zinc-800">
                    Synthesis & Final Recommendation
                </h3>
                <div className="p-4">
                    {isLoading && !debateResult.synthesis 
                        ? <div className="flex items-center gap-2 text-zinc-400"><SpinnerIcon className="w-5 h-5 animate-spin" /><span>Generating synthesis...</span></div>
                        : <MarkdownRenderer content={debateResult.synthesis} />
                    }
                </div>
            </div>
        </div>
    );
};

export default DebateDisplay;