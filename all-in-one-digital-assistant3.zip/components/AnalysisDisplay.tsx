import React from 'react';
import MarkdownRenderer from './MarkdownRenderer';
import { AnalysisTurn } from '../types';
import { InfoIcon } from './icons/InfoIcon';

interface AnalysisDisplayProps {
    analysisResult: AnalysisTurn[] | null;
    isLoading: boolean;
}

const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({ analysisResult, isLoading }) => {
    if (isLoading) {
        return null;
    }

    if (!analysisResult || analysisResult.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-zinc-600 text-center p-4">
                <InfoIcon className="w-12 h-12 mb-4" />
                <p className="text-lg font-medium text-zinc-400">Analysis Results</p>
                <p className="text-sm max-w-sm">The code analysis will be shown here.</p>
            </div>
        );
    }
    
    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {analysisResult.map((turn, index) => (
                    <div key={index} className="border border-zinc-800 rounded-lg bg-zinc-900/50">
                        <h3 className="text-md font-bold text-zinc-200 capitalize p-3 bg-zinc-800/50 rounded-t-lg border-b border-zinc-800">
                           {turn.model.replace(/gemini-2.5-|gemma-2-|-it/g, '')}'s Analysis
                        </h3>
                        <div className="p-4">
                            <MarkdownRenderer content={turn.analysis} />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AnalysisDisplay;