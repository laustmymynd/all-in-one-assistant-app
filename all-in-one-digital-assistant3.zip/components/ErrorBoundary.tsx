import React, { ErrorInfo, ReactNode } from 'react';
import { AlertCircleIcon } from './icons/AlertCircleIcon';
import { CopyIcon } from './icons/CopyIcon';
import { ClipboardCheckIcon } from './icons/ClipboardCheckIcon';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  isCopied: boolean;
}

class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      isCopied: false,
    };
    
    this.handleQuickReset = this.handleQuickReset.bind(this);
    this.handleHardReset = this.handleHardReset.bind(this);
    this.handleCopyError = this.handleCopyError.bind(this);
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
    this.setState({ errorInfo });
  }

  handleQuickReset() {
    try {
        localStorage.removeItem('assistant-session');
    } catch (e) {
        console.error("Failed to clear session from localStorage:", e);
    } finally {
        window.location.reload();
    }
  }
  
  handleHardReset() {
    try {
        localStorage.removeItem('assistant-session');
        localStorage.removeItem('assistant-history');
        localStorage.removeItem('assistant-draft-code');
        localStorage.removeItem('assistant-draft-language');
        localStorage.removeItem('assistant-draft-action');
        localStorage.removeItem('assistant-draft-persona');
        localStorage.removeItem('assistant-draft-web-search');
    } catch (e) {
        console.error("Failed to clear localStorage:", e);
    } finally {
        window.location.reload();
    }
  }

  handleCopyError() {
    if (this.state.error) {
        const errorDetails = `
Error: ${this.state.error.toString()}

Stack: ${this.state.error.stack || 'Not available'}

Component Stack: ${this.state.errorInfo?.componentStack || 'Not available'}
        `;
        navigator.clipboard.writeText(errorDetails.trim());
        this.setState({ isCopied: true });
        setTimeout(() => this.setState({ isCopied: false }), 2000);
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-zinc-950 text-zinc-300 p-4">
          <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-lg shadow-2xl overflow-hidden">
            <div className="flex items-center gap-4 p-4 border-b border-zinc-800 bg-zinc-800/30">
              <AlertCircleIcon className="w-10 h-10 text-red-500 flex-shrink-0" />
              <div>
                <h1 className="text-xl font-bold text-red-400">Application Error</h1>
                <p className="text-sm text-zinc-400">An unexpected problem has occurred, preventing the app from starting correctly.</p>
              </div>
            </div>

            <div className="p-6">
              <div className="bg-zinc-800/50 p-3 rounded-md mb-6 border border-zinc-700">
                <p className="font-mono text-sm text-red-400 break-words">
                  <strong>{this.state.error?.name}:</strong> {this.state.error?.message}
                </p>
              </div>
              
              <h2 className="text-lg font-semibold text-zinc-100 mb-4">How to fix this</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-orange-600 text-white flex items-center justify-center font-bold text-lg">1</div>
                  <div>
                    <h3 className="font-semibold text-zinc-200">Try a Quick Reset</h3>
                    <p className="text-sm text-zinc-400 mb-3">This often fixes temporary issues without losing your work history.</p>
                    <button
                      onClick={this.handleQuickReset}
                      className="px-4 py-1.5 bg-orange-600 text-white text-sm font-semibold rounded-md hover:bg-orange-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-zinc-900 focus:ring-orange-500"
                    >
                      Quick Reset
                    </button>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-red-700 text-white flex items-center justify-center font-bold text-lg">2</div>
                  <div>
                    <h3 className="font-semibold text-zinc-200">Perform a Hard Reset</h3>
                    <p className="text-sm text-zinc-400 mb-3">If the problem persists, this will clear all application data and start fresh. <strong className="text-amber-400">Your session history will be permanently deleted.</strong></p>
                    <button
                      onClick={this.handleHardReset}
                      className="px-4 py-1.5 bg-red-700 text-white text-sm font-semibold rounded-md hover:bg-red-800 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-zinc-900 focus:ring-red-600"
                    >
                      Hard Reset Application
                    </button>
                  </div>
                </div>
              </div>

              <details className="mt-8 text-left bg-zinc-800/50 border border-zinc-700 rounded-md text-xs text-zinc-400">
                <summary className="cursor-pointer font-semibold text-zinc-300 p-3">
                  Show Technical Details for Bug Report
                </summary>
                <div className="relative border-t border-zinc-700 p-3">
                  <button 
                    onClick={this.handleCopyError}
                    className="absolute top-2 right-2 flex items-center gap-1.5 px-2 py-1 bg-zinc-700 hover:bg-zinc-600 rounded text-xs text-zinc-300 transition-colors"
                  >
                    {this.state.isCopied ? <ClipboardCheckIcon className="w-4 h-4 text-green-400" /> : <CopyIcon className="w-4 h-4" />}
                    {this.state.isCopied ? 'Copied!' : 'Copy'}
                  </button>
                  <pre className="mt-4 whitespace-pre-wrap break-words font-mono text-zinc-400">
                    {`Error: ${this.state.error?.toString()}\n\nStack: ${this.state.error?.stack || 'Not available'}\n\nComponent Stack: ${this.state.errorInfo?.componentStack || 'Not available'}`}
                  </pre>
                </div>
              </details>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
