
import React from 'react';
import MarkdownRenderer from './MarkdownRenderer';
import { InfoIcon } from './icons/InfoIcon';
import { AlertCircleIcon } from './icons/AlertCircleIcon';
import { AssistantResult } from '../types';
import { GlobeIcon } from './icons/GlobeIcon';

interface FeedbackDisplayProps {
  result: AssistantResult | null;
  error: string | null;
  isLoading: boolean;
}

const FeedbackDisplay: React.FC<FeedbackDisplayProps> = ({ result, error, isLoading }) => {
  if (isLoading) {
    return null; // The parent component shows a global spinner
  }

  if (error) {
    return (
      <div className="border border-red-800 bg-red-900/30 text-red-300 rounded-lg p-4 flex items-start gap-3">
        <AlertCircleIcon className="w-6 h-6 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-bold text-lg mb-1">An Error Occurred</h3>
          <p className="text-sm">{error}</p>
        </div>
      </div>
    );
  }

  if (!result || !result.text) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-zinc-600 text-center p-4">
        <InfoIcon className="w-12 h-12 mb-4" />
        <p className="text-lg font-medium text-zinc-400">Assistant's Response</p>
        <p className="text-sm max-w-sm">Enter your code and select an action, then run the assistant to see the response here.</p>
      </div>
    );
  }

  const { text, groundingChunks } = result;

  return (
    <div className="border border-zinc-800 rounded-lg bg-zinc-900/50 p-6">
       {groundingChunks && groundingChunks.length > 0 && (
        <div className="border-b border-zinc-800 pb-4 mb-4">
          <h4 className="text-sm font-semibold text-zinc-300 flex items-center gap-2 mb-2">
            <GlobeIcon className="w-4 h-4 text-orange-400" />
            Sources from the Web
          </h4>
          <ul className="list-disc list-inside space-y-1 text-sm">
            {groundingChunks.map((chunk, index) => (
              chunk.web && (
                <li key={index}>
                  <a
                    href={chunk.web.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-orange-400 hover:text-orange-300 hover:underline"
                    title={chunk.web.uri}
                  >
                    {chunk.web.title || chunk.web.uri}
                  </a>
                </li>
              )
            ))}
          </ul>
        </div>
      )}
      <MarkdownRenderer content={text} />
    </div>
  );
};

export default FeedbackDisplay;