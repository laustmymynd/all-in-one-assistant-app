

import React, { useState, useRef, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { ACTIONS, LANGUAGES, PERSONAS, LANGUAGE_DETAILS } from '../constants';
import { CopyIcon } from './icons/CopyIcon';
import { TrashIcon } from './icons/TrashIcon';
import { UploadIcon } from './icons/UploadIcon';
import { PlayIcon } from './icons/PlayIcon';
import { ClipboardCheckIcon } from './icons/ClipboardCheckIcon';
import { GlobeIcon } from './icons/GlobeIcon';

interface AssistantPanelProps {
  onRun: (code: string, language: string, action: string, persona: string, webSearchEnabled: boolean) => void;
  isLoading: boolean;
  onInteraction: () => void;
  initialCode?: string;
  initialLanguage?: string;
  initialAction?: string;
  initialPersona?: string;
  initialWebSearchEnabled?: boolean;
}

const DRAFT_KEYS = {
  CODE: 'assistant-draft-code',
  LANGUAGE: 'assistant-draft-language',
  ACTION: 'assistant-draft-action',
  PERSONA: 'assistant-draft-persona',
  WEB_SEARCH: 'assistant-draft-web-search',
};

const AssistantPanel: React.FC<AssistantPanelProps> = ({ 
  onRun, 
  isLoading, 
  onInteraction,
  initialCode = '', 
  initialLanguage = 'javascript',
  initialAction = 'explain',
  initialPersona = 'Developer',
  initialWebSearchEnabled = false
}) => {
  const [code, setCode] = useState(() => localStorage.getItem(DRAFT_KEYS.CODE) || initialCode);
  const [language, setLanguage] = useState(() => localStorage.getItem(DRAFT_KEYS.LANGUAGE) || initialLanguage);
  const [action, setAction] = useState(() => localStorage.getItem(DRAFT_KEYS.ACTION) || initialAction);
  const [persona, setPersona] = useState(() => localStorage.getItem(DRAFT_KEYS.PERSONA) || initialPersona);
  const [webSearchEnabled, setWebSearchEnabled] = useState(() => {
    try {
      const item = localStorage.getItem(DRAFT_KEYS.WEB_SEARCH);
      // Use draft if it exists and is valid JSON
      if (item !== null) return JSON.parse(item);
    } catch (e) {
      console.warn("Failed to parse web search setting from localStorage.", e);
    }
    // Otherwise, fall back to the prop from restored session or default
    return initialWebSearchEnabled;
  });
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isInitialMount = useRef(true);

  // Save state to localStorage whenever it changes
  useEffect(() => { localStorage.setItem(DRAFT_KEYS.CODE, code); }, [code]);
  useEffect(() => { localStorage.setItem(DRAFT_KEYS.LANGUAGE, language); }, [language]);
  useEffect(() => { localStorage.setItem(DRAFT_KEYS.ACTION, action); }, [action]);
  useEffect(() => { localStorage.setItem(DRAFT_KEYS.PERSONA, persona); }, [persona]);
  useEffect(() => { localStorage.setItem(DRAFT_KEYS.WEB_SEARCH, JSON.stringify(webSearchEnabled)); }, [webSearchEnabled]);


  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }
    onInteraction();
  }, [code, language, action, persona, webSearchEnabled]);

  // Update state when restoring from history
  useEffect(() => {
    setCode(initialCode);
    setLanguage(initialLanguage);
    setAction(initialAction);
    setPersona(initialPersona);
    setWebSearchEnabled(initialWebSearchEnabled);
  }, [initialCode, initialLanguage, initialAction, initialPersona, initialWebSearchEnabled]);

  const handleRun = () => {
    if (code.trim()) {
      onRun(code, language, action, persona, webSearchEnabled);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClear = () => {
    setCode('');
    localStorage.removeItem(DRAFT_KEYS.CODE);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setCode(content);
        const extension = file.name.split('.').pop()?.toLowerCase();
        const detectedLanguage = Object.keys(LANGUAGE_DETAILS).find(
          lang => LANGUAGE_DETAILS[lang].extension === extension
        );
        if (detectedLanguage) {
          setLanguage(detectedLanguage);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950/50 rounded-lg border border-zinc-800 shadow-lg">
      <div className="p-3 border-b border-zinc-800 flex items-center justify-between bg-zinc-900 rounded-t-lg">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <label htmlFor="language-select" className="text-sm font-medium text-zinc-400">Language:</label>
            <select
              id="language-select"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="bg-zinc-800 border border-zinc-700 text-white text-sm rounded-md focus:ring-orange-500 focus:border-orange-500 block w-full p-1.5"
            >
              {LANGUAGES.map((lang) => (
                <option key={lang} value={lang}>{lang.charAt(0).toUpperCase() + lang.slice(1)}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="flex items-center gap-2">
            <button onClick={() => fileInputRef.current?.click()} className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-md transition-colors" title="Upload File">
                <UploadIcon className="w-5 h-5" />
            </button>
            <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
            <button onClick={handleCopy} className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-md transition-colors" title="Copy Code">
                {copied ? <ClipboardCheckIcon className="w-5 h-5 text-green-500" /> : <CopyIcon className="w-5 h-5" />}
            </button>
            <button onClick={handleClear} className="p-2 text-zinc-400 hover:text-red-500 hover:bg-zinc-800 rounded-md transition-colors" title="Clear Code">
                <TrashIcon className="w-5 h-5" />
            </button>
        </div>
      </div>
      <div className="flex-grow relative h-[300px] lg:h-auto">
        <Editor
          height="100%"
          language={language}
          value={code}
          onChange={(value) => setCode(value || '')}
          theme="vs-dark"
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            wordWrap: 'on',
            scrollBeyondLastLine: false,
            automaticLayout: true,
          }}
        />
      </div>
      <div className="p-3 border-t border-zinc-800 bg-zinc-900 rounded-b-lg flex flex-col sm:flex-row items-center gap-4">
        <div className="flex-grow w-full">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                    <label htmlFor="action-select" className="text-sm font-medium text-zinc-400">Action:</label>
                    <select
                        id="action-select"
                        value={action}
                        onChange={(e) => setAction(e.target.value)}
                        className="bg-zinc-800 border border-zinc-700 text-white text-sm rounded-md focus:ring-orange-500 focus:border-orange-500 block w-full p-2"
                    >
                        {ACTIONS.map((act) => (
                            <option key={act} value={act}>{act.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</option>
                        ))}
                    </select>
                </div>
                <div className="flex items-center gap-2">
                    <label htmlFor="persona-select" className="text-sm font-medium text-zinc-400">Persona:</label>
                     <select
                        id="persona-select"
                        value={persona}
                        onChange={(e) => setPersona(e.target.value)}
                        className="bg-zinc-800 border border-zinc-700 text-white text-sm rounded-md focus:ring-orange-500 focus:border-orange-500 block w-full p-2"
                    >
                        {PERSONAS.map((p) => (
                            <option key={p} value={p}>{p}</option>
                        ))}
                    </select>
                </div>
            </div>
             <div className="mt-3 flex items-center gap-2">
                <input
                    type="checkbox"
                    id="web-search-toggle"
                    checked={webSearchEnabled}
                    onChange={(e) => setWebSearchEnabled(e.target.checked)}
                    className="h-4 w-4 rounded border-zinc-600 bg-zinc-700 text-orange-600 focus:ring-orange-500 focus:ring-offset-zinc-900"
                />
                <label htmlFor="web-search-toggle" className="text-sm font-medium text-zinc-300 flex items-center gap-1.5">
                    <GlobeIcon className="w-4 h-4 text-zinc-400" />
                    Web Search
                </label>
            </div>
        </div>
        <button
          onClick={handleRun}
          disabled={isLoading || !code.trim()}
          className="w-full sm:w-auto flex items-center justify-center px-6 py-2 border border-transparent text-base font-medium rounded-md text-white bg-orange-600 hover:bg-orange-700 disabled:bg-zinc-600 disabled:cursor-not-allowed transition-colors"
        >
          <PlayIcon className="w-5 h-5 mr-2" />
          {isLoading ? 'Running...' : 'Run'}
        </button>
      </div>
    </div>
  );
};

export default AssistantPanel;
