import React from 'react';

export const BrainCircuitIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    {...props}
  >
    <path d="M12 2a2.5 2.5 0 0 0-2.5 2.5v.7a.5.5 0 0 1-1 0v-.7A4.5 4.5 0 0 1 12 0a4.5 4.5 0 0 1 4.5 4.5v.7a.5.5 0 0 1-1 0v-.7A2.5 2.5 0 0 0 12 2z" />
    <path d="M12 22a2.5 2.5 0 0 1 2.5-2.5v-.7a.5.5 0 0 0-1 0v.7a.5.5 0 0 1-1 0v-2.1a.5.5 0 0 0-1 0v2.1a.5.5 0 0 1-1 0v-.7a.5.5 0 0 0-1 0v.7a2.5 2.5 0 0 1 2.5 2.5z" />
    <path d="M5 16a2.5 2.5 0 0 1 2.5-2.5v-1a.5.5 0 0 0-1 0v1a.5.5 0 0 1-1 0v-2a.5.5 0 0 0-1 0v2a.5.5 0 0 1-1 0v-1a.5.5 0 0 0-1 0v1a2.5 2.5 0 0 1 2.5 2.5z" />
    <path d="M19 16a2.5 2.5 0 0 0-2.5-2.5v-1a.5.5 0 0 1 1 0v1a.5.5 0 0 0 1 0v-2a.5.5 0 0 1 1 0v2a.5.5 0 0 0 1 0v-1a.5.5 0 0 1 1 0v1a2.5 2.5 0 0 0-2.5 2.5z" />
    <path d="M12 9a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z" />
    <path d="M12 14.5a2.5 2.5 0 0 1 0-5" />
    <path d="M12 9.5a2.5 2.5 0 0 1 0 5" />
    <path d="M14.5 12a2.5 2.5 0 0 0-5 0" />
    <path d="M9.5 12a2.5 2.5 0 0 0 5 0" />
  </svg>
);
