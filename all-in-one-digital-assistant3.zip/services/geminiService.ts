import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ComparisonTurn, DebateTurn, CollaborationTurn, AnalysisTurn, AssistantResult } from '../types';

// Per guidelines, API key must be from process.env.API_KEY
// and the client should be initialized with it directly.
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });


const generateContent = async (model: string, prompt: string, webSearchEnabled?: boolean): Promise<AssistantResult> => {
    try {
        const ai = getAI();
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: webSearchEnabled ? { tools: [{googleSearch: {}}] } : {},
        });
        return {
            text: response.text,
            groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks,
        };
    } catch (error: any) {
        console.error(`Error generating content with ${model}:`, error);
        let message = 'An unknown error occurred.';
        if (error instanceof Error) {
            message = error.message;
            if (message.includes('API key not valid')) {
                message = 'The API key is not valid. Please check your configuration.';
            } else if (message.includes('429')) { // Too Many Requests
                message = 'The model is currently overloaded with requests. Please try again in a few moments.';
            } else if (message.toLowerCase().includes('quota')) {
                message = 'You have exceeded your API quota. Please check your usage limits.';
            } else if (message.toLowerCase().includes('safety')) {
                message = 'The response was blocked due to safety settings. Please adjust your prompt.';
            }
        } else if (typeof error === 'string') {
            message = error;
        }

        throw new Error(`[${model}] ${message}`);
    }
};

export const runAssistant = (model: string, code: string, language: string, action: string, persona: string, webSearchEnabled?: boolean): Promise<AssistantResult> => {
    let prompt = `
        You are a ${persona}.
        Your task is to ${action} the following ${language} code.
        Provide a detailed and helpful response. Format your response using Markdown.
    `;

    if (webSearchEnabled) {
        prompt += `
If relevant, use Google Search to find the most current information. Cite your sources.`;
    }

    prompt += `
        \`\`\`${language}
        ${code}
        \`\`\`
    `;
    return generateContent(model, prompt, webSearchEnabled);
};

export const runComparison = async (models: string[], code: string, language: string, action: string, persona: string): Promise<ComparisonTurn[]> => {
    const results: ComparisonTurn[] = await Promise.all(models.map(async (model) => {
        try {
            const { text: output } = await runAssistant(model, code, language, action, persona);
            return { model, output };
        } catch (error) {
            console.error(`Error with model ${model} in comparison:`, error);
            return { model, output: '', error: error instanceof Error ? error.message : 'Unknown error' };
        }
    }));
    return results;
};

export const runDebate = async (models: string[], code: string, language: string, action: string, persona: string): Promise<{ turns: DebateTurn[], synthesis: string }> => {
    if (models.length < 2) {
        throw new Error("Debate mode requires at least two models.");
    }
    
    const firstTwoModels = models.slice(0, 2);
    
    // 1. Initial responses
    const initialResponses = await Promise.all(
        firstTwoModels.map(async model => 
            (await runAssistant(model, code, language, action, persona)).text
        )
    );

    // 2. Rebuttals
    const rebuttalPrompts = [
        `You are ${firstTwoModels[0]}. Your opponent (${firstTwoModels[1]}) provided this response:\n\n---\n${initialResponses[1]}\n\n---\n\nYour original response was:\n\n---\n${initialResponses[0]}\n\n---\n\nCritique your opponent's response and strengthen your own argument about the ${language} code.`,
        `You are ${firstTwoModels[1]}. Your opponent (${firstTwoModels[0]}) provided this response:\n\n---\n${initialResponses[0]}\n\n---\n\nYour original response was:\n\n---\n${initialResponses[1]}\n\n---\n\nCritique your opponent's response and strengthen your own argument about the ${language} code.`
    ];

    const rebuttals = await Promise.all(
        firstTwoModels.map(async (model, i) => (await generateContent(model, rebuttalPrompts[i])).text)
    );

    const turns: DebateTurn[] = firstTwoModels.map((model, i) => ({
        model,
        initialResponse: initialResponses[i],
        rebuttal: rebuttals[i]
    }));

    // 3. Synthesis
    const synthesisPrompt = `
        You are a neutral expert synthesizing a debate between two AI assistants (${firstTwoModels.join(' and ')}).
        They were tasked to ${action} a piece of ${language} code.

        Here is the debate:
        
        **${turns[0].model}'s Argument:**
        *Initial Response:* ${turns[0].initialResponse}
        *Rebuttal:* ${turns[0].rebuttal}
        
        **${turns[1].model}'s Argument:**
        *Initial Response:* ${turns[1].initialResponse}
        *Rebuttal:* ${turns[1].rebuttal}

        Synthesize their arguments, identify the strongest points from each, and provide a final, conclusive recommendation for the user.
    `;
    // Using a more powerful model for synthesis
    const synthesisModel = 'gemini-2.5-pro';
    const { text: synthesis } = await generateContent(synthesisModel, synthesisPrompt);

    return { turns, synthesis };
};

export const runCollaboration = async (models: string[], code: string, language: string, action: string, persona: string, turns = 3): Promise<CollaborationTurn[]> => {
    let currentCode = code;
    const collaborationHistory: CollaborationTurn[] = [];

    for (let i = 0; i < turns; i++) {
        const model = models[i % models.length]; // Cycle through models
        const prompt = `
            You are a ${persona} collaborating on a piece of code.
            This is turn ${i + 1} of the collaboration.
            Your task is to ${action} the code.
            
            Here is the current version of the code:
            \`\`\`${language}
            ${currentCode}
            \`\`\`
            
            Provide ONLY the improved, complete code block. Do not add explanations or surrounding text.
        `;
        const { text: suggestion } = await generateContent(model, prompt);
        const cleanedSuggestion = suggestion.replace(/```(?:\w*\n)?([\s\S]*?)```/g, '$1').trim();
        
        collaborationHistory.push({
            turn: i + 1,
            model: model,
            suggestion: cleanedSuggestion
        });
        currentCode = cleanedSuggestion;
    }
    
    return collaborationHistory;
};

export const runAnalysis = async (models: string[], code: string, language: string, action: string, persona: string): Promise<AnalysisTurn[]> => {
    const results: AnalysisTurn[] = await Promise.all(models.map(async (model) => {
        try {
            const { text: analysis } = await runAssistant(model, code, language, action, persona);
            return { model, analysis };
        } catch (error) {
            console.error(`Error with model ${model} in analysis:`, error);
            return { model, analysis: `Error: ${error instanceof Error ? error.message : 'Unknown error'}` };
        }
    }));
    return results;
};

export const runScholarlyReview = (model: string, code: string, language: string): Promise<AssistantResult> => {
    const prompt = `
        You are a world-class computer science professor and a peer reviewer for a prestigious academic journal.
        Your task is to provide a scholarly peer review of the following ${language} code submission.
        
        Analyze the code for the following:
        - Correctness and adherence to language best practices.
        - Algorithmic efficiency (Time and Space complexity).
        - Readability, maintainability, and code structure.
        - Potential security vulnerabilities.
        - Novelty or interesting patterns.

        Structure your review like a formal academic paper review. Provide constructive criticism and suggest specific improvements.
        Format your response in Markdown.

        \`\`\`${language}
        ${code}
        \`\`\`
    `;
    return generateContent(model, prompt);
};