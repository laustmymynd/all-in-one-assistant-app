import React from 'react';
import { Interaction } from '../types';

interface HistoryPanelProps {
  history: Interaction[];
  onRestore: (item: Interaction) => void;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, onRestore }) => {
  if (history.length === 0) {
    return <div className="p-4 text-center text-zinc-500">No history yet.</div>;
  }

  return (
    <div className="p-2 space-y-2">
      {history.slice().reverse().map(item => (
        <button
          key={item.id}
          onClick={() => onRestore(item)}
          className="w-full text-left p-2 bg-zinc-800 hover:bg-zinc-700 rounded-md transition-colors"
        >
          <div className="font-semibold text-zinc-200 capitalize">{item.mode}: {item.action}</div>
          <div className="text-xs text-zinc-400">{new Date(item.timestamp).toLocaleString()}</div>
        </button>
      ))}
    </div>
  );
};

export default HistoryPanel;