import React, { useMemo } from 'react';
import ReactFlow, { Background, Controls, MiniMap, Node, Edge, Position } from 'reactflow';
import dagre from 'dagre';
import { Interaction } from '../types';
import HistoryNode from './HistoryNode';
import 'reactflow/dist/style.css';
import './KnowledgeGraph.css';

interface KnowledgeGraphProps {
  history: Interaction[];
  onRestore: (item: Interaction) => void;
}

const nodeTypes = { historyNode: HistoryNode };

const dagreGraph = new dagre.graphlib.Graph();
dagreGraph.setDefaultEdgeLabel(() => ({}));

const nodeWidth = 220;
const nodeHeight = 80;

const getLayoutedElements = (nodes: Node[], edges: Edge[], direction = 'TB') => {
  const isHorizontal = direction === 'LR';
  dagreGraph.setGraph({ rankdir: direction, nodesep: 30, ranksep: 60 });

  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: nodeWidth, height: nodeHeight });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  nodes.forEach((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    node.targetPosition = isHorizontal ? Position.Left : Position.Top;
    node.sourcePosition = isHorizontal ? Position.Right : Position.Bottom;

    // We are shifting the dagre node position (anchor=center center) to the top left
    // so it matches the React Flow node anchor point (top left).
    node.position = {
      x: nodeWithPosition.x - nodeWidth / 2,
      y: nodeWithPosition.y - nodeHeight / 2,
    };

    return node;
  });

  return { nodes, edges };
};


const KnowledgeGraph: React.FC<KnowledgeGraphProps> = ({ history, onRestore }) => {

  const layoutedElements = useMemo(() => {
    if (history.length === 0) {
        return { nodes: [], edges: [] };
    }
    
    const nodes: Node[] = history.map(item => ({
        id: item.id,
        type: 'historyNode',
        data: { interaction: item },
        position: { x: 0, y: 0 }, // Initial position, will be updated by layout
    }));

    const edges: Edge[] = history
        .filter(item => item.parentId && history.some(h => h.id === item.parentId))
        .map(item => ({
            id: `e-${item.parentId}-${item.id}`,
            source: item.parentId!,
            target: item.id,
            type: 'smoothstep',
            animated: true,
            style: { stroke: '#f97316' },
        }));
    
    return getLayoutedElements(nodes, edges, 'TB');

  }, [history]);

  const onNodeClick = (_event: React.MouseEvent, node: Node) => {
    const interaction = history.find(h => h.id === node.id);
    if (interaction) {
      onRestore(interaction);
    }
  };

  return (
    <div className="knowledge-graph-container">
      <ReactFlow
        nodes={layoutedElements.nodes}
        edges={layoutedElements.edges}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        fitView
      >
        <Background color="#3f3f46" gap={16} />
        <Controls />
        <MiniMap nodeColor="#f97316" nodeStrokeWidth={3} zoomable pannable />
      </ReactFlow>
    </div>
  );
};

export default KnowledgeGraph;
