import React, { useState, useRef, useEffect } from 'react';
import './BrowserWindow.css';

const BrowserWindow: React.FC = () => {
  const [url, setUrl] = useState('https://example.com');
  const [inputUrl, setInputUrl] = useState('https://example.com');
  const [history, setHistory] = useState(['https://example.com']);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [showDevTools, setShowDevTools] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Handle URL navigation
  const navigateTo = (newUrl: string) => {
    let formattedUrl = newUrl;
    if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
      formattedUrl = `https://${newUrl}`;
    }
    
    setUrl(formattedUrl);
    setInputUrl(formattedUrl);
    
    // Add to history
    if (formattedUrl !== history[historyIndex]) {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(formattedUrl);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
    }
    
    setIsLoading(true);
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    navigateTo(inputUrl);
  };

  // Navigation handlers
  const goBack = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      setHistoryIndex(newIndex);
      setUrl(history[newIndex]);
      setInputUrl(history[newIndex]);
      setIsLoading(true);
    }
  };

  const goForward = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      setHistoryIndex(newIndex);
      setUrl(history[newIndex]);
      setInputUrl(history[newIndex]);
      setIsLoading(true);
    }
  };

  const refresh = () => {
    if (iframeRef.current) {
      setIsLoading(true);
      iframeRef.current.src = url;
    }
  };

  const goHome = () => {
    navigateTo('https://example.com');
  };

  // Iframe event handlers
  const handleIframeLoad = () => {
    setIsLoading(false);
  };

  const handleIframeError = () => {
    setIsLoading(false);
    console.error('Failed to load page');
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 'r':
            e.preventDefault();
            refresh();
            break;
          case 'l':
            e.preventDefault();
            (document.querySelector('.url-bar-input') as HTMLElement)?.focus();
            break;
          case 'h':
            e.preventDefault();
            goHome();
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Sample bookmarks
  const bookmarks = [
    { name: 'Google', url: 'https://google.com' },
    { name: 'GitHub', url: 'https://github.com' },
    { name: 'MDN', url: 'https://developer.mozilla.org' },
    { name: 'React', url: 'https://react.dev' },
  ];

  return (
    <div className="browser-window">
      {/* Browser Controls */}
      <div className="browser-controls">
        <div className="window-controls">
          <div className="control close"></div>
          <div className="control minimize"></div>
          <div className="control maximize"></div>
        </div>
        
        {/* Navigation Bar */}
        <div className="nav-bar">
          <div className="nav-buttons">
            <button 
              className="nav-btn" 
              onClick={goBack}
              disabled={historyIndex === 0}
              title="Go Back"
            >
              ←
            </button>
            <button 
              className="nav-btn" 
              onClick={goForward}
              disabled={historyIndex === history.length - 1}
              title="Go Forward"
            >
              →
            </button>
            <button 
              className="nav-btn" 
              onClick={refresh}
              title="Reload (Ctrl+R)"
            >
              ↻
            </button>
            <button 
              className="nav-btn" 
              onClick={goHome}
              title="Home (Ctrl+H)"
            >
              ⌂
            </button>
          </div>

          {/* URL Bar */}
          <form className="url-bar" onSubmit={handleSubmit}>
            <input
              type="text"
              className="url-bar-input"
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              placeholder="Enter URL..."
              spellCheck="false"
              aria-label="URL Input"
            />
            <button type="submit" className="go-btn" aria-label="Navigate">Go</button>
          </form>

          {/* Dev Tools Toggle */}
          <button 
            className="dev-tools-btn"
            onClick={() => setShowDevTools(!showDevTools)}
            title="Toggle Developer Tools"
            aria-label="Toggle Developer Tools"
          >
            🔧
          </button>
        </div>

        {/* Bookmarks Bar */}
        <div className="bookmarks-bar">
          {bookmarks.map((bookmark) => (
            <button
              key={bookmark.name}
              className="bookmark"
              onClick={() => navigateTo(bookmark.url)}
              title={bookmark.url}
            >
              {bookmark.name}
            </button>
          ))}
        </div>
      </div>

      {/* Browser Content */}
      <div className="browser-content">
         {isLoading && (
            <div className="loading-indicator">
              <div className="loading-spinner"></div>
              <span>Loading {url}...</span>
            </div>
          )}
        <iframe
          ref={iframeRef}
          src={url}
          title="browser-content"
          onLoad={handleIframeLoad}
          onError={handleIframeError}
          style={{ 
            border: 'none', 
            width: '100%', 
            height: showDevTools ? '70%' : '100%',
            visibility: isLoading ? 'hidden' : 'visible'
          }}
          sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals"
          allow="camera; microphone; geolocation"
        />
        
        {/* Developer Tools */}
        {showDevTools && (
          <div className="dev-tools">
            <div className="dev-tools-header">
              <h4>Developer Tools</h4>
              <button 
                onClick={() => setShowDevTools(false)}
                className="close-devtools"
                aria-label="Close Developer Tools"
              >
                ×
              </button>
            </div>
            <div className="dev-tools-content">
              <div className="dev-tools-section">
                <h5>Page Information</h5>
                <p><strong>Current URL:</strong> {url}</p>
                <p><strong>History:</strong> {history.length} pages</p>
                <p><strong>Position:</strong> {historyIndex + 1} of {history.length}</p>
              </div>
              <div className="dev-tools-section">
                <h5>Quick Actions</h5>
                <button onClick={() => navigator.clipboard.writeText(url)}>
                  Copy URL
                </button>
                <button onClick={() => console.log('Page source:', iframeRef.current)}>
                  View Source
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Status Bar */}
      <div className="status-bar">
        <span>{isLoading ? 'Loading...' : 'Ready'}</span>
        <span>|</span>
        <span>{url}</span>
      </div>
    </div>
  );
};

export default BrowserWindow;
