
import React from 'react';

export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M12 2L14.39 8.61L21 11L14.39 13.39L12 20L9.61 13.39L3 11L9.61 8.61L12 2Z" />
    <path d="M4.5 15.5L6 14L7.5 15.5L9 14L7.5 12.5L9 11L7.5 9.5L6 11L4.5 9.5L3 11L4.5 12.5L3 14L4.5 15.5Z" />
    <path d="M15 4.5L14 6L15 7.5L14 9L12.5 7.5L11 9L9.5 7.5L11 6L9.5 4.5L11 3L12.5 4.5L14 3L15 4.5Z" />
  </svg>
);
