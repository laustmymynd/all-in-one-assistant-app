import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { Interaction } from '../types';
import { CodeIcon } from './icons/CodeIcon';
import { PencilSwooshIcon } from './icons/PencilSwooshIcon';
import { WandIcon } from './icons/WandIcon';
import { SearchIcon } from './icons/SearchIcon';
import { SparklesIcon } from './icons/SparklesIcon';


const getIcon = (action: string) => {
    switch (action) {
        case 'explain': return <PencilSwooshIcon className="w-5 h-5" />;
        case 'find-bugs': return <SearchIcon className="w-5 h-5" />;
        case 'refactor': return <CodeIcon className="w-5 h-5" />;
        case 'generate-docs': return <WandIcon className="w-5 h-5" />;
        case 'optimize': return <SparklesIcon className="w-5 h-5" />;
        default: return <CodeIcon className="w-5 h-5" />;
    }
}

const HistoryNode: React.FC<NodeProps<{ interaction: Interaction }>> = ({ data }) => {
  const { interaction } = data;
  const { action, language, timestamp } = interaction;
  
  const formattedDate = new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="history-node cursor-pointer">
      <Handle type="target" position={Position.Top} className="!bg-zinc-700" />
      <div className="flex items-center gap-3">
        <div className="p-2 bg-zinc-800 rounded-md text-orange-500">
            {getIcon(action)}
        </div>
        <div>
            <div className="font-bold text-white capitalize">{action.replace('-', ' ')}</div>
            <div className="text-xs text-zinc-400">{language} - {formattedDate}</div>
        </div>
      </div>
       <Handle type="source" position={Position.Bottom} className="!bg-zinc-700" />
    </div>
  );
};

export default memo(HistoryNode);
