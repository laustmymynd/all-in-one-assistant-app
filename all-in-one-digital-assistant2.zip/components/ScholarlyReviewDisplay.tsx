
import React from 'react';
import MarkdownRenderer from './MarkdownRenderer';
import { InfoIcon } from './icons/InfoIcon';

interface ScholarlyReviewDisplayProps {
    reviewContent: string | null;
    isLoading: boolean;
}

const ScholarlyReviewDisplay: React.FC<ScholarlyReviewDisplayProps> = ({ reviewContent, isLoading }) => {
    if (isLoading) {
        return null;
    }

    if (!reviewContent) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-zinc-600 text-center p-4">
                <InfoIcon className="w-12 h-12 mb-4" />
                <p className="text-lg font-medium text-zinc-400">Scholarly Review</p>
                <p className="text-sm max-w-sm">The peer review of your code will appear here.</p>
            </div>
        );
    }

    return (
        <div className="border border-zinc-800 rounded-lg bg-zinc-900/50">
            <h3 className="text-md font-bold text-zinc-200 p-3 bg-zinc-800/50 rounded-t-lg border-b border-zinc-800">
                Scholarly Peer Review
            </h3>
            <div className="p-6">
                <MarkdownRenderer content={reviewContent} />
            </div>
        </div>
    );
};

export default ScholarlyReviewDisplay;
