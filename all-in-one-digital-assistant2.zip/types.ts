
export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web: GroundingChunkWeb;
}

export interface AssistantResult {
  text: string;
  groundingChunks?: GroundingChunk[];
}

export interface ComparisonTurn {
  model: string;
  output: string;
  error?: string | null;
}

export interface DebateTurn {
  model: string;
  initialResponse: string;
  rebuttal: string;
}

export interface CollaborationTurn {
  turn: number;
  model: string;
  suggestion: string;
}

export interface AnalysisTurn {
    model: string;
    analysis: string;
}

export type InteractionResult = 
    AssistantResult | 
    ComparisonTurn[] | 
    { turns: DebateTurn[], synthesis: string } | 
    CollaborationTurn[] |
    AnalysisTurn[] |
    null;

export interface Interaction {
  id: string;
  timestamp: number;
  parentId: string | null;
  mode: InteractionMode;
  code: string;
  language: string;
  action: string;
  persona: string;
  webSearchEnabled?: boolean;
  result: InteractionResult;
  error: string | null;
}

export type InteractionMode = 
  | 'assistant'
  | 'comparison'
  | 'debate'
  | 'collaboration'
  | 'analysis'
  | 'scholarly-review'
  | 'history'
  | 'browser';

export type ModelSelection = {
  [key in InteractionMode]?: string | string[];
};