

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Header from './components/Header';
import Background from './components/Background';
import AssistantPanel from './components/AssistantPanel';
import FeedbackDisplay from './components/FeedbackDisplay';
import SettingsModal from './components/SettingsModal';
import { ComparisonPanel } from './components/ComparisonPanel';
import {
  runAssistant,
  runComparison,
  runDebate,
  runCollaboration,
  runAnalysis,
  runScholarlyReview
} from './services/geminiService';
import { Interaction, InteractionMode, ModelSelection, InteractionResult, ComparisonTurn, DebateTurn, CollaborationTurn, AnalysisTurn, AssistantResult } from './types';
import { AVAILABLE_MODELS, GEMMA_MODELS } from './constants';
import { AssistantIcon } from './components/icons/AssistantIcon';
import { BalanceIcon } from './components/icons/BalanceIcon';
import { DebateIcon } from './components/icons/DebateIcon';
import { CollaborateIcon } from './components/icons/CollaborateIcon';
import { GraphIcon } from './components/icons/GraphIcon';
import { ShieldCheckIcon } from './components/icons/ShieldCheckIcon';
import { HistoryIcon } from './components/icons/HistoryIcon';
import { BrowserIcon } from './components/icons/BrowserIcon';
import { SpinnerIcon } from './components/icons/SpinnerIcon';
import DebateDisplay from './components/DebateDisplay';
import CollaborationDisplay from './components/CollaborationDisplay';
import AnalysisDisplay from './components/AnalysisDisplay';
import ScholarlyReviewDisplay from './components/ScholarlyReviewDisplay';
import HistoryDashboard from './components/HistoryDashboard';
import BrowserWindow from './components/BrowserWindow';

const SESSION_KEY = 'assistant-session';

// Helper to ensure model selections for multi-model modes are always arrays
const getModelsAsArray = (models: string | string[] | undefined): string[] => {
  if (Array.isArray(models)) return models;
  if (typeof models === 'string' && models) return [models];
  return [];
};


const App: React.FC = () => {
  const [mode, setMode] = useState<InteractionMode>('assistant');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<InteractionResult>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<Interaction[]>([]);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [settings, setSettings] = useState<ModelSelection>({
    assistant: AVAILABLE_MODELS[0],
    comparison: [AVAILABLE_MODELS[0], GEMMA_MODELS[0]],
    debate: [AVAILABLE_MODELS[0], GEMMA_MODELS[0]],
    collaboration: [AVAILABLE_MODELS[0], GEMMA_MODELS[0]],
    analysis: [AVAILABLE_MODELS[0], GEMMA_MODELS[0]],
    'scholarly-review': AVAILABLE_MODELS[1],
  });
  const [currentInteraction, setCurrentInteraction] = useState<Partial<Interaction> | null>(null);
  const [selectedHistoryId, setSelectedHistoryId] = useState<string | null>(null);
  const isInitialMount = useRef(true);

  // Load state from localStorage on initial mount
  useEffect(() => {
    try {
        const savedHistory = localStorage.getItem('assistant-history');
        if (savedHistory) {
            const parsed = JSON.parse(savedHistory);
            if (Array.isArray(parsed)) {
                setHistory(parsed);
            } else {
                console.warn("Malformed history data in localStorage, discarding.");
                localStorage.removeItem('assistant-history');
            }
        }
    } catch (e) {
        console.error("Failed to parse history data from localStorage", e);
        localStorage.removeItem('assistant-history');
    }

    const savedSession = localStorage.getItem(SESSION_KEY);
    if (savedSession) {
      try {
        const session = JSON.parse(savedSession);
        if (session && typeof session === 'object' && !Array.isArray(session)) {
            const restoredMode = session.mode || 'assistant';
            let restoredResult = session.result || null;
            
            // Validate that the restored result matches the restored mode to prevent crashes
            if (restoredResult) {
              const arrayModes: InteractionMode[] = ['comparison', 'collaboration', 'analysis'];
              const textModes: InteractionMode[] = ['assistant', 'scholarly-review'];
              
              const resultIsArray = Array.isArray(restoredResult);
              const resultIsDebate = typeof restoredResult === 'object' && restoredResult !== null && 'turns' in restoredResult && 'synthesis' in restoredResult;
              const resultIsText = typeof restoredResult === 'object' && restoredResult !== null && 'text' in restoredResult;
    
              if (arrayModes.includes(restoredMode) && !resultIsArray) {
                restoredResult = null; // Mismatch: mode expects array, result is not
              } else if (restoredMode === 'debate' && !resultIsDebate) {
                restoredResult = null; // Mismatch: mode is debate, result is not debate object
              } else if (textModes.includes(restoredMode) && !resultIsText) {
                restoredResult = null; // Mismatch: mode expects text object, result is not
              }
            }
            
            setMode(restoredMode);
            setResult(restoredResult);
            setError(session.error || null);
            
            // Safely apply restored settings
            const restoredSettings = session.settings;
            if (restoredSettings && typeof restoredSettings === 'object' && !Array.isArray(restoredSettings)) {
              setSettings(prev => ({ ...prev, ...restoredSettings }));
            }
    
            setCurrentInteraction(session.currentInteraction || null);
            setSelectedHistoryId(session.selectedHistoryId || null);
        }
      } catch (e) {
        console.error("Failed to parse session data from localStorage", e);
        localStorage.removeItem(SESSION_KEY);
      }
    }
  }, []);

  // Save session state to localStorage whenever it changes
  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }
    const sessionToSave = {
      mode,
      result,
      error,
      settings,
      currentInteraction,
      selectedHistoryId,
    };
    localStorage.setItem(SESSION_KEY, JSON.stringify(sessionToSave));
  }, [mode, result, error, settings, currentInteraction, selectedHistoryId]);

  // Persist history separately as it can grow large
  useEffect(() => {
    localStorage.setItem('assistant-history', JSON.stringify(history));
  }, [history]);

  const addToHistory = (interaction: Omit<Interaction, 'id' | 'timestamp'>) => {
    const newInteraction: Interaction = {
      ...interaction,
      id: uuidv4(),
      timestamp: Date.now(),
    };
    setHistory(prev => [...prev, newInteraction]);
  };

  const handleRun = async (code: string, language: string, action: string, persona: string, webSearchEnabled: boolean) => {
    setIsLoading(true);
    setError(null);
    setResult(null);

    const parentId = selectedHistoryId;
    const interactionData = { code, language, action, persona, parentId, webSearchEnabled };
    setCurrentInteraction(interactionData);
    setSelectedHistoryId(null); // Consume the parentId

    let response: InteractionResult = null;
    let responseError: string | null = null;

    try {
      switch (mode) {
        case 'assistant':
          response = await runAssistant(settings.assistant as string, code, language, action, persona, webSearchEnabled);
          break;
        case 'comparison':
          response = await runComparison(getModelsAsArray(settings.comparison), code, language, action, persona);
          break;
        case 'debate':
          response = await runDebate(getModelsAsArray(settings.debate), code, language, action, persona);
          break;
        case 'collaboration':
          response = await runCollaboration(getModelsAsArray(settings.collaboration), code, language, action, persona);
          break;
        case 'analysis':
          response = await runAnalysis(getModelsAsArray(settings.analysis), code, language, action, persona);
          break;
        case 'scholarly-review':
          response = await runScholarlyReview(settings['scholarly-review'] as string, code, language);
          break;
      }
      setResult(response);
    } catch (e: any) {
      setError(e.message || 'An unexpected error occurred.');
      responseError = e.message || 'An unexpected error occurred.';
    } finally {
      setIsLoading(false);
      addToHistory({ ...interactionData, mode, result: response, error: responseError });
    }
  };

  const handleRestoreInteraction = useCallback((item: Interaction) => {
    setMode(item.mode);
    setResult(item.result);
    setError(item.error);
    setCurrentInteraction({
      code: item.code,
      language: item.language,
      action: item.action,
      persona: item.persona,
      webSearchEnabled: item.webSearchEnabled,
    });
    setSelectedHistoryId(item.id);
  }, []);

  const handleClearHistory = () => {
    if (window.confirm('Are you sure you want to clear the entire session history? This cannot be undone.')) {
      setHistory([]);
      // Clear all related localStorage items for a full reset
      localStorage.removeItem('assistant-history');
      localStorage.removeItem(SESSION_KEY);
      localStorage.removeItem('assistant-draft-code');
      localStorage.removeItem('assistant-draft-language');
      localStorage.removeItem('assistant-draft-action');
      localStorage.removeItem('assistant-draft-persona');
      localStorage.removeItem('assistant-draft-web-search');
      // Force a reload to ensure all state is reset cleanly
      window.location.reload();
    }
  };
  
  const handleModeChange = (newMode: InteractionMode) => {
    setMode(newMode);
    setResult(null);
    setError(null);
    setCurrentInteraction(null);
    setSelectedHistoryId(null);
  }

  const renderMainContent = () => {
    if (mode === 'history') {
        return <HistoryDashboard history={history} onRestore={handleRestoreInteraction} onClearHistory={handleClearHistory} />;
    }
    if (mode === 'browser') {
        return <BrowserWindow />;
    }

    // Default view for assistant modes
    return (
        <div className="flex flex-col lg:flex-row gap-4 h-full">
            <div className="w-full lg:w-1/2 xl:w-5/12">
                <AssistantPanel 
                    onRun={handleRun} 
                    isLoading={isLoading}
                    onInteraction={() => setSelectedHistoryId(null)} // New interaction breaks the history link
                    key={selectedHistoryId || 'new-draft'} // Use a key to force re-render on restore
                    initialCode={currentInteraction?.code}
                    initialLanguage={currentInteraction?.language}
                    initialAction={currentInteraction?.action}
                    initialPersona={currentInteraction?.persona}
                    initialWebSearchEnabled={currentInteraction?.webSearchEnabled}
                />
            </div>
            <div className="w-full lg:w-1/2 xl:w-7/12 min-h-[400px] lg:min-h-0">
                {renderFeedbackContent()}
            </div>
        </div>
    );
  };

  const renderFeedbackContent = () => {
    if (isLoading && !result) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-zinc-500">
          <SpinnerIcon className="w-12 h-12 animate-spin text-orange-500" />
          <p className="mt-4 text-lg">Assistant is thinking...</p>
        </div>
      );
    }

    switch (mode) {
      case 'assistant':
        return <FeedbackDisplay result={result as AssistantResult | null} error={error} isLoading={isLoading} />;
      case 'comparison': {
        const comparisonResult = result as ComparisonTurn[] | null;
        const comparisonModels = getModelsAsArray(settings.comparison);
        
        return (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 h-full">
            {comparisonModels.map(modelName => (
              <ComparisonPanel
                key={modelName}
                modelName={modelName}
                content={comparisonResult?.find(r => r.model === modelName)?.output || ''}
                error={comparisonResult?.find(r => r.model === modelName)?.error || (error && modelName === comparisonModels[0] ? error : null)}
                isLoading={isLoading}
                language={currentInteraction?.language || 'javascript'}
              />
            ))}
          </div>
        );
      }
      case 'debate':
        return <DebateDisplay debateResult={result as { turns: DebateTurn[], synthesis: string } | null} isLoading={isLoading} />;
      case 'collaboration':
        return <CollaborationDisplay collaborationResult={result as CollaborationTurn[] | null} isLoading={isLoading} language={currentInteraction?.language || 'javascript'} />;
      case 'analysis':
        return <AnalysisDisplay analysisResult={result as AnalysisTurn[] | null} isLoading={isLoading} />;
      case 'scholarly-review':
        return <ScholarlyReviewDisplay reviewContent={(result as AssistantResult | null)?.text ?? null} isLoading={isLoading} />;
      default:
        return null;
    }
  };

  const modes = [
    { id: 'assistant', label: 'Assistant', icon: AssistantIcon },
    { id: 'comparison', label: 'Comparison', icon: BalanceIcon },
    { id: 'debate', label: 'Debate', icon: DebateIcon },
    { id: 'collaboration', label: 'Collaboration', icon: CollaborateIcon },
    { id: 'analysis', label: 'Analysis', icon: GraphIcon },
    { id: 'scholarly-review', label: 'Scholarly Review', icon: ShieldCheckIcon },
    { id: 'history', label: 'History', icon: HistoryIcon },
    { id: 'browser', label: 'Browser', icon: BrowserIcon },
  ];

  return (
    <div className="bg-zinc-950 text-zinc-200 font-sans min-h-screen flex flex-col">
      <Background />
      <Header onToggleSettings={() => setIsSettingsOpen(true)} />

      <main className="container mx-auto p-4 flex-grow flex flex-col gap-4">
        <div className="flex flex-col md:flex-row gap-4 flex-grow">
            <div className="w-full md:w-1/3 lg:w-1/4 flex-shrink-0">
                <nav className="bg-zinc-900/50 border border-zinc-800 rounded-lg p-3 space-y-2">
                    {modes.map(m => (
                        <button
                            key={m.id}
                            onClick={() => handleModeChange(m.id as InteractionMode)}
                            className={`w-full flex items-center gap-3 p-3 rounded-md text-sm font-medium transition-colors ${
                                mode === m.id ? 'bg-orange-600/20 text-orange-400' : 'text-zinc-400 hover:bg-zinc-800/70 hover:text-zinc-200'
                            }`}
                        >
                            <m.icon className="w-5 h-5" />
                            <span>{m.label}</span>
                        </button>
                    ))}
                </nav>
            </div>

            <div className="w-full flex-grow">
                {renderMainContent()}
            </div>
        </div>
      </main>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSettingsChange={setSettings}
      />
    </div>
  );
};

export default App;