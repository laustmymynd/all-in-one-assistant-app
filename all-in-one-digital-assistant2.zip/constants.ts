import { ModelSelection } from './types';

export const ACTIONS = [
  'explain',
  'find-bugs',
  'refactor',
  'generate-docs',
  'optimize',
];

export const LANGUAGES = [
  'javascript',
  'python',
  'typescript',
  'java',
  'csharp',
  'go',
  'html',
  'css',
  'sql',
  'ruby',
  'rust',
];

export const PERSONAS = [
  'Developer',
  'Code-Mentor',
  'Tech-Lead',
  'Junior-Developer',
  'Security-Analyst',
];

export const LANGUAGE_DETAILS: { [key: string]: { extension: string; mime: string } } = {
  javascript: { extension: 'js', mime: 'application/javascript' },
  python: { extension: 'py', mime: 'text/x-python' },
  typescript: { extension: 'ts', mime: 'application/typescript' },
  java: { extension: 'java', mime: 'text/x-java-source' },
  csharp: { extension: 'cs', mime: 'text/plain' },
  go: { extension: 'go', mime: 'text/x-go' },
  html: { extension: 'html', mime: 'text/html' },
  css: { extension: 'css', mime: 'text/css' },
  sql: { extension: 'sql', mime: 'application/sql' },
  ruby: { extension: 'rb', mime: 'text/x-ruby' },
  rust: { extension: 'rs', mime: 'text/rust' },
};

export const AVAILABLE_MODELS = [
    'gemini-2.5-flash',
    'gemini-2.5-pro',
];

export const GEMMA_MODELS = [
    'gemma-2-9b-it',
    'gemma-2-27b-it',
];


export const MODEL_PRESETS: { name: string; description: string; config: ModelSelection }[] = [
    {
        name: 'Speed Priority',
        description: 'Uses the fastest models (Flash) for responsive, everyday tasks.',
        config: {
            assistant: 'gemini-2.5-flash',
            comparison: ['gemini-2.5-flash', 'gemma-2-9b-it'],
            debate: ['gemini-2.5-flash', 'gemma-2-9b-it'],
            collaboration: ['gemini-2.5-flash', 'gemini-2.5-flash'],
            analysis: ['gemini-2.5-flash', 'gemma-2-9b-it'],
            'scholarly-review': 'gemini-2.5-pro',
        },
    },
    {
        name: 'Quality Priority',
        description: 'Uses the most powerful models (Pro & Gemma 27b) for the highest quality results.',
        config: {
            assistant: 'gemini-2.5-pro',
            comparison: ['gemini-2.5-pro', 'gemma-2-27b-it'],
            debate: ['gemini-2.5-pro', 'gemma-2-27b-it'],
            collaboration: ['gemini-2.5-pro', 'gemini-2.5-flash'],
            analysis: ['gemini-2.5-pro', 'gemma-2-27b-it'],
            'scholarly-review': 'gemini-2.5-pro',
        },
    },
    {
        name: 'Maximum Diversity',
        description: 'Mixes different model families to get the most varied perspectives in multi-model modes.',
        config: {
            assistant: 'gemini-2.5-flash',
            comparison: ['gemini-2.5-pro', 'gemma-2-9b-it'],
            debate: ['gemini-2.5-pro', 'gemma-2-27b-it'],
            collaboration: ['gemini-2.5-flash', 'gemma-2-9b-it'],
            analysis: ['gemini-2.5-pro', 'gemma-2-27b-it'],
            'scholarly-review': 'gemini-2.5-pro',
        },
    }
];
